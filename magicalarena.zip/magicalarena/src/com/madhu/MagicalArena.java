package com.madhu;

public class MagicalArena {

	public String playGame(Player player1, Player player2) {

		var attacker = player1.getHealth() > player2.getHealth() ? player2 : player1;

		var defender = attacker == player1 ? player2 : player1;

		while (player1.getHealth() > 0 && player2.getHealth() > 0) {

			System.out.println("Attacker is " + attacker);
			System.out.println("Defender is " + defender);

			System.out.println("Roll Dice for Attacker " + attacker.getPlayerId());

			int attackerDiceNumber = attacker.rollDice();

			System.out.println("Attacker " + attacker.getPlayerId() + " Rolled Dice With Result " + attackerDiceNumber);

			int attackerAttackPower = attackerDiceNumber * attacker.getAttackPower();

			System.out.println("Attacker " + attacker.getPlayerId() + " Attack Power is " + attackerAttackPower);

			System.out.println("Roll Dice For Defender " + defender.getPlayerId());

			int defenderDiceNumber = attacker.rollDice();

			System.out.println("Defender " + defender.getPlayerId() + " Rolled Dice With Result " + defenderDiceNumber);

			int defenderStrengthPower = defenderDiceNumber * defender.getStrength();

			System.out.println("Defender " + defender.getPlayerId() + " Strength is " + defenderStrengthPower);

			int effectedDamage = Math.max(0, attackerAttackPower - defenderStrengthPower);

			System.out.println("Health Reduced For Defender " + defender.getPlayerId() + " is " + effectedDamage);

			defender.reduceHealth(effectedDamage);

			System.out.println("Switching Players");
			var tempPlayer = attacker;
			attacker = defender;
			defender = tempPlayer;

		}

		return attacker.getHealth() > 0 ? attacker.getPlayerId() : defender.getPlayerId();

	}

}
