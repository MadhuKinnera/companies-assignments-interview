package com.madhu;

public class Player {

	private String playerId;
	private Integer health;
	private Integer attackPower;
	private Integer strength;

	public Player() {

	}

	public Player(String playerId, Integer health, Integer attackPower, Integer strength) {
		super();
		this.playerId = playerId;
		this.health = health;
		this.attackPower = attackPower;
		this.strength = strength;
	}

	public String getPlayerId() {
		return playerId;
	}

	public void setPlayerId(String playerId) {
		this.playerId = playerId;
	}

	public Integer getHealth() {
		return health;
	}

	public void setHealth(Integer health) {
		this.health = health;
	}

	public Integer getAttackPower() {
		return attackPower;
	}

	public void setAttackPower(Integer attackPower) {
		this.attackPower = attackPower;
	}

	public Integer getStrength() {
		return strength;
	}

	public void setStrength(Integer strength) {
		this.strength = strength;
	}

	public int rollDice() {

		var value = Math.random();

		int maxValue = 7;
		var res = (int) (maxValue * value);

		return res == 0 ? 1 : res;

	}

	public void reduceHealth(int damage) {
		health -= damage;
		if (health < 0) {
			health = 0;
		}
	}

	@Override
	public String toString() {
		return "Player [playerId=" + playerId + ", health=" + health + ", attackPower=" + attackPower + ", strength="
				+ strength + "]";
	}

}
