package com.madhu;

import java.util.List;
import java.util.Random;

public class TestCases {

	public static void main(String[] args) {

		var player1 = new Player("Player A", 70, 15, 17);
		var player2 = new Player("Player B", 100, 46, 18);
		var player3 = new Player("Player C", 80, 18, 25);
		var player4 = new Player("Player D", 95, 25, 30);
		var player5 = new Player("Player E", 50, 30, 12);
		var player6 = new Player("Player F", 20, 11, 10);
		var player7 = new Player("Player G", 45, 16, 22);
		var player8 = new Player("Player H", 65, 35, 24);
		var player9 = new Player("Player I", 15, 50, 28);
		var player10 = new Player("Player J", 92, 38, 5);

		var players = List.of(player1, player2, player3, player4, player5, player6, player7, player8, player9,
				player10);

		var randomPlayer1 = getRandomPlayer(players);
		var randomPlayer2 = getRandomPlayer(players, randomPlayer1);

		var magicalArena = new MagicalArena();

		var winner = magicalArena.playGame(randomPlayer1, randomPlayer2);

		System.out.println("Player 1 is " + randomPlayer1);
		System.out.println("Player 2 is " + randomPlayer2);
		
		System.out.println(" The Winner is " + winner);

	}

	private static Player getRandomPlayer(List<Player> playerList) {
		if (playerList != null && playerList.size() > 0) {
			Random random = new Random();
			int randomIndex = random.nextInt(playerList.size());
			return playerList.get(randomIndex);
		} else {
			return null;
		}
	}

	private static Player getRandomPlayer(List<Player> playerList, Player playerToExclude) {
		if (playerList != null && playerList.size() > 1) {
			Player randomPlayer = getRandomPlayer(playerList);

			while (randomPlayer.equals(playerToExclude)) {
				randomPlayer = getRandomPlayer(playerList);
			}

			return randomPlayer;
		} else {
			return null;
		}
	}

}
