# Magical Arena Java Project

## Description

The Magical Arena is a Java project that simulates battles between magical creatures.

## Getting Started

### Prerequisites

- Java 8 or higher

### Installation

1. Extract The zip file Provided to you
2. Import the Project as Java Project In you Eclipse/STS

## Usage

To use the Magical Arena, follow these steps:

1. Run the `MagicalArena` class.
2. Follow the on-screen instructions to set up players and start a battle.

